from flask import Flask, render_template, request, redirect, url_for, session
import psycopg2
from datetime import datetime
import uuid


app = Flask(__name__)
app.secret_key = 'my_very_secret_key_123'  # replace this with something stronger later


DB_CONFIG = {
    "host": "localhost",
    "port": 5432,
    "database": "postgres",
    "user": "myuser",
    "password": "mypassword"
}

@app.route('/')
def index():
    return render_template('login.html', error=None)

@app.route('/login', methods=['POST'])
def login():
    email = request.form['email']
    password = request.form['password']

    try:
        conn = psycopg2.connect(**DB_CONFIG)
        cur = conn.cursor()
        cur.execute("""
            SELECT plan_type, start_date, end_date 
            FROM Subscriptions 
            WHERE email = %s AND password = %s AND status = 'active';
        """, (email, password))
        result = cur.fetchone()

        if result:
            # Save email in session
            session['email'] = email
            cur.close()
            conn.close()
            return redirect(url_for('profiles'))  # ✅ redirect to /profiles
        else:
            cur.close()
            conn.close()
            return render_template('login.html', error="Invalid credentials or inactive subscription.")

    except Exception as e:
        return render_template('login.html', error=(e))

@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'GET':
        return render_template('register.html', error=None)

    # POST method
    name = request.form['name']
    birth_date = request.form['birth_date']
    country = request.form['country']
    email = request.form['email']
    password = request.form['password']
    plan = request.form['plan']

    try:
        conn = psycopg2.connect(**DB_CONFIG)
        cur = conn.cursor()

        # Step 1: Create new user_id
        cur.execute("SELECT MAX(user_id) FROM Users;")
        max_id = cur.fetchone()[0] or 0
        new_user_id = max_id + 1

        # Step 2: Insert into Users
        cur.execute("""
            INSERT INTO Users (user_id, name, birth_date, country)
            VALUES (%s, %s, %s, %s);
        """, (new_user_id, name, birth_date, country))

        # Step 3: Insert into Subscriptions
        cur.execute("""
            INSERT INTO Subscriptions (email, password, plan_type, start_date, status, user_id)
            VALUES (%s, %s, %s, %s, %s, %s);
        """, (email, password, plan, datetime.now().date(), 'active', new_user_id))

        conn.commit()
        cur.close()
        conn.close()

        return redirect(url_for('index'))

    except Exception as e:
        return render_template('register.html', error=f"Error: {e}")

@app.route('/profiles')
def profiles():
    email = session.get('email')
    if not email:
        return redirect(url_for('index'))

    try:
        conn = psycopg2.connect(**DB_CONFIG)
        cur = conn.cursor()
        cur.execute("""
            SELECT profile_id, name FROM profiles WHERE email = %s;
        """, (email,))
        profiles = cur.fetchall()
        cur.close()
        conn.close()

        #colors = ['#e50914', '#ff8c00', '#1e90ff', '#32cd32', '#8a2be2', '#ff1493', '#00ced1', '#ffa500']

        return render_template('profiles.html', profiles=profiles) # , colors=colors)

    except Exception as e:
        return f"<p>Error loading profiles: {e}</p>"

@app.route('/add_profile', methods=['GET', 'POST'])
def add_profile():
    email = session.get('email')
    if not email:
        return redirect(url_for('index'))

    if request.method == 'GET':
        return render_template('add_profile.html', error=None)

    # POST
    name = request.form['name']
    age_rating = request.form['age_rating']
    created_at = datetime.now().date()

    try:
        conn = psycopg2.connect(**DB_CONFIG)
        cur = conn.cursor()

        # Generate new profile_id
        cur.execute("SELECT MAX(profile_id) FROM profiles;")
        max_id = cur.fetchone()[0] or 0
        new_profile_id = max_id + 1

        cur.execute("""
            INSERT INTO profiles (name, age_rating, created_at, profile_id, email)
            VALUES (%s, %s, %s, %s, %s);
        """, (name, age_rating, created_at, new_profile_id, email))

        conn.commit()
        cur.close()
        conn.close()

        return redirect(url_for('profiles'))

    except Exception as e:
        return render_template('add_profile.html', error=str(e))

@app.route('/profile/<int:profile_id>')
def profile(profile_id):
    try:
        conn = psycopg2.connect(**DB_CONFIG)
        cur = conn.cursor()

        # Fetch profile name
        cur.execute("SELECT name FROM profiles WHERE profile_id = %s;", (profile_id,))
        profile_row = cur.fetchone()
        if not profile_row:
            return "Profile not found.", 404
        profile_name = profile_row[0]

        # Watch list
        cur.execute("""
            SELECT c.title_id, c.title_name, wl.added_at
            FROM watch_list wl
            JOIN title c ON wl.title_id = c.title_id
            WHERE wl.profile_id = %s;
            """, (profile_id,))
        watch_list_rows = cur.fetchall()

        watch_list = [(name, added_at) for _, name, added_at in watch_list_rows]
        content_id_map = {name: content_id for content_id, name, _ in watch_list_rows}

        # Watch history
        cur.execute("""
            SELECT c.title_name, wh.watched_at, wh.rating
            FROM watch_history wh
            JOIN title c ON wh.title_id = c.title_id
            WHERE wh.profile_id = %s;
        """, (profile_id,))
        watch_history_rows = cur.fetchall()
        watch_history = [(name, watched_at, rating) for name, watched_at, rating in watch_history_rows]
        # update the shared content_id map with history entries too
        for name, watched_at, rating in watch_history:
            if name not in content_id_map:
                cur.execute("SELECT title_id FROM title WHERE title_name = %s", (name,))
                row = cur.fetchone()
            if row:
                content_id_map[name] = row[0]
        
        # Top 10 most watched content
        cur.execute("""
            SELECT c.title_id, c.title_name, COUNT(*) AS views
            FROM watch_history wh
            JOIN title c ON wh.title_id = c.title_id
            GROUP BY c.title_id, c.title_name
            ORDER BY views DESC
            LIMIT 10;
        """)
        top_content = cur.fetchall()
        
        # Top 10 highest rated content
        cur.execute("""
            SELECT c.title_id, c.title_name, ROUND(AVG(rating), 2) AS avg_rating
            FROM watch_history wh
            JOIN title c ON wh.title_id = c.title_id
            WHERE wh.rating IS NOT NULL
            GROUP BY c.title_id, c.title_name
            ORDER BY avg_rating DESC
            LIMIT 10;
        """)
        top_rated = cur.fetchall()

        cur.close()
        conn.close()

        return render_template('profile.html',
                       profile_name=profile_name,
                       watch_history=watch_history,
                       watch_list=watch_list,
                       content_id_map=content_id_map,
                       profile_id=profile_id,
                       top_content=top_content,
                       top_rated=top_rated)

    except Exception as e:
        return f"Error: {e}", 500
        
@app.route('/add_to_watch_list', methods=['POST'])
def add_to_watch_list():
    profile_id = request.form['profile_id']
    content_id = request.form['content_id']

    try:
        conn = psycopg2.connect(**DB_CONFIG)
        cur = conn.cursor()

        # Avoid duplicate entry
        cur.execute("""
            SELECT 1 FROM watch_list WHERE profile_id = %s AND title_id = %s
        """, (profile_id, content_id))
        if not cur.fetchone():
            cur.execute("""
                INSERT INTO watch_list (added_at, profile_id, title_id)
                VALUES (%s, %s, %s);
            """, (datetime.now().date(), profile_id, content_id))
            conn.commit()

        cur.close()
        conn.close()

        return redirect(url_for('profile', profile_id=profile_id))

    except Exception as e:
        return f"Error: {e}", 500

@app.route('/mark_as_watched', methods=['POST'])
def mark_as_watched():
    profile_id = request.form['profile_id']
    content_id = request.form['content_id']

    try:
        conn = psycopg2.connect(**DB_CONFIG)
        cur = conn.cursor()

        # Remove from watch list
        cur.execute("""
            DELETE FROM watch_list WHERE profile_id = %s AND title_id = %s;
        """, (profile_id, content_id))

        # Add to watch history
        cur.execute("""
            INSERT INTO watch_history (watched_at, rating, profile_id, title_id)
            VALUES (%s, %s, %s, %s);
        """, (datetime.now().date(), None, profile_id, content_id))

        conn.commit()
        cur.close()
        conn.close()

        return redirect(url_for('profile', profile_id=profile_id))

    except Exception as e:
        return f"Error: {e}", 500
        
@app.route('/rate_content', methods=['POST'])
def rate_content():
    profile_id = request.form['profile_id']
    content_id = request.form['content_id']
    rating = request.form['rating']

    if rating == '':
        rating = None  # handle blank selection

    try:
        conn = psycopg2.connect(**DB_CONFIG)
        cur = conn.cursor()

        cur.execute("""
            UPDATE watch_history
            SET rating = %s
            WHERE profile_id = %s AND title_id = %s;
        """, (rating, profile_id, content_id))

        conn.commit()
        cur.close()
        conn.close()

        return redirect(url_for('profile', profile_id=profile_id))

    except Exception as e:
        return f"Error updating rating: {e}", 500

if __name__ == '__main__':
    app.run(debug=True)
